export default {
    USER_REGISTER : "/user/register",
    USER_LOGIN    : "/user/login",
}